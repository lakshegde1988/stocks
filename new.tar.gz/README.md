chartz is a tool to check charts of NSE india stocks
